import streamlit as st
import pandas as pd
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

# Function to load custom CSS
def load_css():
    with open("style.css") as f:
        st.markdown(f"<style>{f.read()}</style>", unsafe_allow_html=True)

# Load CSS styling
load_css()

# Set app title and header
st.image("travel_banner.jpg", use_container_width=True)  # Image banner
st.title("🌍 Travel Recommender")

# Data paths
# Path to cleaned datasets
data_path = "C:/Users/isabe/OneDrive/Ambiente de Trabalho/projeto final/cleaned_datasets/"

# Dictionary with correct file paths for all datasets
datasets = {
    "events": "event_locations_combined - event_locations_combined - event_locations_combined - event_locations_combined_cleaned.csv_cleaned.csv",
    "hotels": "hotels_hostels_combined - hotels_hostels_combined - hotels_hostels_combined - hotels_hostels_combined_cleaned.csv_cleaned.csv",
    "nature": "nature_spots_combined - nature_spots_combined - nature_spots_combined - nature_spots_combined_cleaned.csv_cleaned.csv",
    "restaurants": "restaurants_bars_cafes_combined - restaurants_bars_cafes_combined - restaurants_bars_cafes_combined - restaurants_bars_cafes_combined_cleaned.csv_cleaned.csv",
    "tourist_attractions": "tourist_attractions_combined - tourist_attractions_combined_cleaned.csv - tourist_attractions_combined - tourist_attractions_combined_cleaned.csv_cleaned.csv",
    "transit": "transit_stops_combined - transit_stops_combined - transit_stops_combined - transit_stops_combined_cleaned.csv_cleaned.csv",
    "weather": "weather_data_combined - weather_data_combined_cleaned.csv - weather_data_combined - weather_data_combined_cleaned.csv_cleaned.csv",
}

# Load datasets (without displaying messages in Streamlit)
dfs = {}
for key, file in datasets.items():
    try:
        df = pd.read_csv(data_path + file)
        df.fillna("Unknown", inplace=True)
        dfs[key] = df
        print(f"✅ {key} dataset loaded successfully! ({df.shape[0]} rows)")  # Message only in console
    except Exception as e:
        print(f"❌ Error loading {key}: {e}")  # Error only in console

# Get available countries and cities
if "events" in dfs:
    countries = dfs["events"]["country"].unique().tolist()
    selected_country = st.selectbox("🌍 Select a country:", countries)

    cities = dfs["events"][dfs["events"]["country"] == selected_country]["city"].unique().tolist()
    selected_city = st.selectbox("🏙️ Select a city:", cities)

# Allow users to choose what they want to explore
category_options = {
    "events": "🎭 Events",
    "hotels": "🏨 Hotels",
    "nature": "🌿 Nature",
    "restaurants": "🍽️ Restaurants",
    "tourist_attractions": "🏰 Attractions",
    "transit": "🚉 Transport",
}
selected_categories = st.multiselect("⚡ What do you want to explore?", category_options.keys(), format_func=lambda x: category_options[x])

# Generate recommendations button
if st.button("✨ Get Recommendations"):
    st.markdown(f"🔎 **Displaying recommendations for {selected_city}...**")

    # Filter data based on user choices
    filtered_dfs = {key: dfs[key][dfs[key]["city"] == selected_city] for key in selected_categories if key in dfs}

    # Display results
    for key, df in filtered_dfs.items():
        if not df.empty:
            st.subheader(f"{category_options[key]} in {selected_city}")
            for _, row in df.head(3).iterrows():
                st.markdown(f"**{row['name']}** ({row['type']})")
                st.markdown(f"📍 {row.get('address', 'Unknown location')}")
                st.write("---")

    # Display weather information
    if "weather" in dfs and selected_city in dfs["weather"]["city"].values:
        weather = dfs["weather"][dfs["weather"]["city"] == selected_city].iloc[0]
        st.subheader("🌦️ Current Weather")
        st.markdown(f"🌡️ Temperature: {weather['temperature']}°C")
        st.markdown(f"💧 Humidity: {weather['humidity']}%")
        st.markdown(f"☁️ Condition: {weather['weather'].capitalize()}")
    else:
        st.warning(f"⚠️ No weather data available for {selected_city}.")
